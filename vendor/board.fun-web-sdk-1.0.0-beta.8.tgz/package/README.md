# @board.fun/web-sdk

Build web games for Board, the tabletop gaming platform with physical piece tracking.

The Board Web SDK is a TypeScript wrapper over the JavaScript bridges injected into
the Board WebView by the host OS. It exposes APIs for touch and Piece input,
multiplayer sessions, save games, player avatars, and the system pause menu.

## Install

Starting fresh? `npm create @board.fun/game my-game` scaffolds a ready-to-pack
project (add `-- --template showcase` for a full working reference) — see
`@board.fun/create-game`. For an existing project:

```bash
npm install @board.fun/web-sdk
```

The package is ESM-only and works with any modern ESM bundler (e.g. Vite, webpack 5,
esbuild, rollup, Parcel).

If you have been granted access to the source repository, you can also install it
directly with npm's `github:<owner>/<repo>` shorthand; the owner/repo coordinate is
provided with your access grant.

## Requirements

- Node 18+ for the build toolchain
- Any modern ESM-compatible bundler (e.g. Vite, webpack 5, esbuild, rollup, Parcel)
- A Board device for runtime; in a normal browser the SDK loads, but device calls
  must be gated on `Board.isOnDevice`

## Input

### Piece Set Models

Every packed game bundles a Piece Set Model — the `.tflite` file the device
uses to recognize your Pieces — and the host loads that packed model when your
game launches. A bundle may carry more than one model; a game hot-swaps between
them at runtime with `Board.input.activateModel` (parity with the Board Godot
SDK) and reads the loaded one with `Board.input.getActiveModel()`.

`model` is a bundle-relative path inside your installed bundle (e.g.
`"model.tflite"` or `"models/arcade.tflite"`). The optional `positionSmoothing`,
`rotationSmoothing`, and `persistence` fields tune the tracker; omitted fields
keep the host's defaults.

Model hot-reload is an optional host capability. On OS builds that predate it,
`activateModel` rejects with `BoardModelReloadUnsupportedError` and
`getActiveModel()` returns `null` — catch the error and keep playing with the
launch model (never branch on a version number):

```ts
import { Board, BoardModelReloadUnsupportedError } from "@board.fun/web-sdk";

async function switchToArcadePieces() {
  try {
    await Board.input.activateModel({ model: "models/arcade.tflite" });
  } catch (err) {
    if (err instanceof BoardModelReloadUnsupportedError) {
      // This OS build can't hot-swap models; stay on the launch model.
      return;
    }
    throw err; // e.g. the path does not exist in the installed bundle
  }
}
```

### Hand input

Enable hand detection with `Board.input.setHandDetectionEnabled(true)`.
Hand contacts have type `BoardContactType.Hand` (`BoardContactType.Blob` is a
deprecated alias). Read `contact.handShape` as
`BoardHandShape.Unknown`, `CuppedLeft`, `CuppedRight`, or `CuppedBoth`.
Unknown shape IDs from a newer device map to `Unknown`. A hand's footprint
ellipse is in `contact.handAxes` (`{ major, minor }` radii in display pixels,
not diameters), absent
on hosts whose touch channel predates hand-axis reporting.

A hand's `glyphId` carries its raw shape id (0–3), so identify Pieces with
`contact.type === BoardContactType.Glyph` before reading `glyphId`; a bare
`glyphId > 0` check also matches cupped hands.

Hand `orientation` follows the ellipse's minor axis. When drawing with
`CanvasRenderingContext2D.ellipse`, use the major radius first and rotate by
`(contact.orientation - 90) * Math.PI / 180`. Position and radii already use
display pixels; no Unity coordinate conversion is needed.

Hand detection needs an OS build with the touch-in-OS update. On older builds
the toggle is a no-op and no hand contacts arrive. Display orientation
(`Board.application.canControlDisplayOrientation`, `getDisplayOrientation()`,
`setDisplayOrientation()`) needs the same update; on older builds the getter
reads `false`, `getDisplayOrientation()` returns `Normal` and
`setDisplayOrientation()` returns `false`.

### Contacts across an app pause

`Board.application.onPause` fires when the system menu opens. Before the
callbacks run, the SDK drops its maintained contact snapshot, because the host
may restart piece detection while the app is paused. Contacts seen before the
pause are not carried over and no `Ended` contacts are synthesized; Pieces
reappear as `Began` once detected again.

## Pause menu

Custom-button icons are `"circular_arrow"`, `"door_with_arrow"`,
`"left_arrow"`, `"square"`, or `""`. The older spellings without underscores are
deprecated; the SDK still accepts them and sends the underscore form.

Audio-track sliders are display-only on the OS side. Their values come back
with the final pause result (any action, including resume), not live and not
on a back-out without a choice. The game applies them, persists them and
re-sends them with `Board.pause.updateContext`. `pollResult()` is a legacy
poll that keeps returning the last result until the menu is next dismissed.

## Saves

- Call save APIs once `Board.session.areServicesReady()` is true, and create or
  update a save only while the session has players.
- `Board.save.list()` returns the app's saves for every profile on the device.
  Filter by the active profile's `playerId` against each save's `players`.
- There is no direct delete: `removePlayersFromSave(id)` removes the game's
  players and the OS deletes the save once none remain.
- `playedTime` is in seconds.
- No current OS build supports save covers, so a `cover` argument rejects with
  `BoardCoverUnsupportedError`; catch it and save without a cover.

## Documentation

The [quick start](https://docs.dev.board.fun/web/getting-started/quick-start),
[guides](https://docs.dev.board.fun/guides/), and full
[API reference](https://docs.dev.board.fun/web/reference/api) live in the developer
docs at https://docs.dev.board.fun/. The developer portal at https://dev.board.fun/
has the downloads (e.g. Piece Set Models, the `board-connect` CLI).

To get a built game onto a Board, pack it with `@board.fun/web-pack` and install it
with Board Connect; the
[Build & Deploy guide](https://docs.dev.board.fun/web/getting-started/build-and-deploy)
walks through the full flow.

## License

Proprietary, governed by the Developer Terms of Use, published at
https://docs.dev.board.fun/more/license.
