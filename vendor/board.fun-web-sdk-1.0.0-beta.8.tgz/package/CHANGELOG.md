# Changelog

All notable changes to the Board Web SDK are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0-beta.8] - 2026-10-13

### New

- Hand detection: `input.setHandDetectionEnabled(true)` opts in to hand contacts (`BoardContactType.Hand`), each carrying a `handShape` (`BoardHandShape.Unknown` / `CuppedLeft` / `CuppedRight` / `CuppedBoth`) and a footprint ellipse in `handAxes`. Off by default, so games that don't use hands pay nothing. A hand's `glyphId` carries its raw shape id (0–3), so once hand detection is on, identify Pieces with `type === BoardContactType.Glyph` before reading `glyphId` — a bare `glyphId > 0` check also matches cupped hands. An unrecognized or newer shape id reads as `Unknown` rather than a raw cast. Requires an OS build with the touch-in-OS update; on older builds the toggle is a no-op and no hand contacts arrive.
- Display orientation: `application.canControlDisplayOrientation`, `application.getDisplayOrientation()` and `application.setDisplayOrientation(orientation)` with the new `BoardDisplayOrientation` enum (`Normal` / `Flipped`) let a game flip the panel 180° for its session. Touch stays compensated by the OS. Requires an OS build with the touch-in-OS update; on older builds the getter is `false`, `getDisplayOrientation()` returns `Normal` and `setDisplayOrientation()` returns `false`.
- Overlay anchor: `application.setOverlayAnchor(overlay, anchor)` and `application.resetOverlayAnchor(overlay)` move the system menu button for the game's session; check `application.canRepositionOverlays` first (Board OS 2.2.0+), or catch `BoardOverlayUnsupportedError`.
- Touch-model hot reload: `input.activateModel(options)` asks the host to load a different piece-recognition model from the installed bundle at runtime, and `input.getActiveModel()` reports the loaded model's bundle-relative path (parity with the Godot SDK's `input.activate`). Supported by current Board Browser builds; on hosts without it `activateModel` rejects with `BoardModelReloadUnsupportedError` — catch it and continue with the launch model — and `getActiveModel()` returns `null`.
- `BoardPauseButtonIcon` names the pause-menu icons: `"circular_arrow"`, `"door_with_arrow"`, `"left_arrow"`, `"square"`, or `""`.

### Fixed

- Pause-menu custom buttons now show their icons. The menu only recognizes the underscore names, so the documented `"circulararrow"`, `"doorwitharrow"` and `"leftarrow"` showed no icon. The SDK now sends the underscore form for either spelling.
- Contacts no longer go stale across the system pause menu. Opening it starts a new contact observation epoch: cached contacts are dropped before `application.onPause` callbacks, without synthesizing `Ended` contacts, so pieces seen before the pause don't linger as `Stationary`. Fresh frames received before resume are kept.
- `input.getCurrentContacts()` documentation: it returns the host's latest contact event batch, so an empty result means no new contact events rather than an empty Board surface. Use `subscribe()` / `getContacts()` for SDK-maintained state, or reconcile polled batches in the game.

### Deprecated

- `BoardContactType.Blob`: use `BoardContactType.Hand` (same value). `Blob` remains as an alias so existing code compiles.
- The pause icon spellings `"circulararrow"`, `"doorwitharrow"` and `"leftarrow"` (`BoardPauseButtonLegacyIcon`): use the underscore names. They are still accepted.

### Changed

- Documentation corrections:
  - Pause audio-track values come back once, with the final pause result of any action (including resume) — not live, and not when the player backs out of the menu. The OS never applies them; the game applies them, persists them and re-sends them with `setContext`/`updateContext`.
  - `pause.pollResult()` keeps returning the last result until the menu is next dismissed.
  - No current OS build supports save covers; a `cover` argument rejects with `BoardCoverUnsupportedError`.
  - Saves need `session.areServicesReady()` and players in the session. `save.list()` returns the app's saves for every profile on the device; filter by the active profile's `playerId`. Delete a save by removing all of the game's players.
  - `session.getActiveProfile()` always reports `sessionId` `-1`, which `presentReplacePlayer` refuses; use the profile's seat from `getPlayers()`. Omitting `aiTypeIndices` offers every registered AI type.
  - `application.onPause` / `onResume` are delivered by current Board Browser builds.

## [1.0.0-beta.7] - 2026-07-11

### New

- App lifecycle hooks: `application.onPause(cb)` and `application.onResume(cb)`, delivered by current Board Browser builds.
- Save cover images: `save.create(...)` and `save.update(...)` accept an optional `cover` (Blob, HTMLCanvasElement, ImageBitmap, or data-URL), normalized to a 432×243 PNG, matching the Unity SDK. On hosts without cover-write support the call rejects with `BoardCoverUnsupportedError`; catch it and retry without a cover.
- `input.getCurrentContacts()`: synchronous poll of the host's latest contact event batch. Returns `[]` off-device.
- `session.onPlayersChanged(cb)` and `session.onActiveProfileChanged(cb)`: subscribe to roster and active-profile changes; each returns an unsubscribe function. On current hosts, change detection has roughly 1 second of latency.
- `web-pack` now verifies the bundled touch model is a real TFLite file and fails packing with a clear error otherwise.

### Fixed

- `Ended` and `Canceled` contact phases are now delivered to `subscribe()` callbacks, once, in the frame the contact ends. Piece-lift detection via `phase === Ended` now works as documented.
- Finger contacts now report `type: Finger`. Previously every contact reported `type: Glyph`; keep identifying pieces by `glyphId`.

### Breaking

- `playedTime` is now seconds rather than milliseconds, on both the `create`/`update` parameter and `BoardSaveGameMetadata.playedTime`. This aligns the web SDK with the Unity SDK and how the OS interprets the value. Games that passed or displayed milliseconds must switch to seconds.

## [1.0.0-beta.6] - 2026-06-12

### Changed

- README: point to `@board.fun/create-game` for scaffolding new projects.

## [1.0.0-beta.5] - 2026-06-11

### Changed

- README: point to `@board.fun/web-pack` for packaging and deploy.

## [1.0.0-beta.4] - 2026-06-11

### Fixed

- Pause menu results are now delivered reliably to all apps.
- `BoardPauseResult.action` now matches the documented action names.

## [1.0.0-beta.3] - 2026-06-02

### Changed

- Trim published package metadata.

## [1.0.0-beta.2] - 2026-06-02

### Changed

- Update the reference to the license location.

## [1.0.0-beta.1] - 2026-06-02

First public **beta** of the Board Web SDK. Capability parity with the Board
Unity SDK, exposing the Board platform API surface to web games through the
`Board` namespace injected into the Board WebView by the host OS.

> **This is a beta.** It has had only limited testing on real hardware — expect
> rough edges, and please report anything you hit. The public `Board.*` API is
> append-only and stable in intent, but details may still change before the
> `1.0.0` release.

Supports:

- **Touch & Piece input** — per-frame contact snapshots with Glyph identity,
  position, orientation, lifecycle phase, and hand-presence.
- **Session & player management** — OS-owned roster via the player selector,
  profiles and guests, the active system profile, and the profile switcher
  overlay.
- **Save game management** — create, load, list, and update save games, plus
  removing the game's players from a save (the active profile or all of the
  game's players); the OS deletes a save once no players remain. Includes cover
  images and per-app storage limits.
- **Player avatars** — load player avatar images as data URIs.
- **System pause overlay** — a game-defined pause menu with custom buttons and
  live audio-track controls, plus result polling.

For the full API reference, guides, and setup, see
[docs.dev.board.fun](https://docs.dev.board.fun/).

### Compatibility

- **Board OS minimum:** 1.10.0 or newer.
- **Node 18+** for the build toolchain.
- **Runtime:** arm64-v8a Board devices.
- ESM-only package — consumed by any modern ESM bundler (Vite, webpack 5,
  esbuild, rollup, Parcel).

[1.0.0-beta.8]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.7]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.6]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.5]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.4]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.3]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.2]: https://docs.dev.board.fun/more/changelog
[1.0.0-beta.1]: https://docs.dev.board.fun/more/changelog
